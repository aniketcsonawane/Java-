/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dropbox;

//import com.dropbox.core.DbxException;
//import com.dropbox.core.v2.DbxClientV2;
//import com.dropbox.core.v2.files.FileMetadata;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;

/**
 *
 * @author welcome
 */
public class DownloadFile {
    
    
//    public void downloadDropboxFile(DbxClientV2 client) throws FileNotFoundException, DbxException, IOException
//    {
//                //file name and path Where you want to download this file
//         OutputStream downloadFile = new FileOutputStream("F://rahul.txt");
//                try
//                {
//                    //find the file name cloud of that Name
//                FileMetadata metadata = client.files().downloadBuilder("/tushar.txt").download(downloadFile);
//                }
//                finally
//                {
//                    downloadFile.close();
//                }
//               
//                System.out.println("File Downloaded Successfully");
//        
//    }
    
}
